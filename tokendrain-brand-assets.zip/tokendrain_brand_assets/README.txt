Tokendrain brand assets

Included files:
- tokendrain-logo-stacked.png       Main stacked logo (mascot above wordmark)
- tokendrain-mascot-only.png        Mascot only on transparent background
- tokendrain-logo-horizontal.png    Horizontal logo lockup on transparent background
- tokendrain-wordmark.png           Wordmark only on transparent background
- tokendrain-app-icon.png           App icon / avatar version
- tokendrain-logo-monochrome.png    One-color stacked logo on transparent background
- tokendrain-header-dark.png        Dark header / banner logo

Excluded:
- The last generated banner image was intentionally removed from this pack.
